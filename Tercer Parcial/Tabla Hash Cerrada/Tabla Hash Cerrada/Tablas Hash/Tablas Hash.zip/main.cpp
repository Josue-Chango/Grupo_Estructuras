#include "HashTable.h"
#include "MenuValidation.h"
#include <iostream>

int main()
{
    std::cout << "Iniciando programa..." << std::endl; // Mensaje de depuración

    int tableSize = MenuValidation::getTableSize();
    int probingMethod = MenuValidation::getProbingMethod();
    HashTable letterTable(true, probingMethod, tableSize);  // Tabla para letras
    HashTable numberTable(false, probingMethod, tableSize); // Tabla para números
    int option;

    do
    {
        MenuValidation::displayMenu();
        option = MenuValidation::getMenuOption();

        switch (option)
        {
        case 1:
        {
            std::string value = MenuValidation::getValue(true);
            letterTable.insert(value);
            break;
        }
        case 2:
        {
            std::string value = MenuValidation::getValue(false);
            numberTable.insert(value);
            break;
        }
        case 3:
            letterTable.visualize();
            break;
        case 4:
            numberTable.visualize();
            break;
        case 5:
            std::cout << "Saliendo del programa..." << std::endl; // Mensaje de depuración
            return 0;
        }
    } while (true);

    return 0;
}