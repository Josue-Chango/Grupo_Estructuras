#include "HashTable.h"
#include <iostream>
#include <windows.h>
#include <cmath>
#include <algorithm>

using namespace std;

float HashTable::prevx = 0;
float HashTable::prevy = 0;

HashTable::HashTable(bool letterMode, int probingMethod, int tableSize) : isLetterMode(letterMode), probingMethod(probingMethod), TABLE_SIZE(tableSize)
{
    std::cout << "Inicializando tabla hash..." << std::endl; // Mensaje de depuración
    table = new HashNode*[TABLE_SIZE];
    for (int i = 0; i < TABLE_SIZE; i++)
    {
        table[i] = nullptr;
    }
    initializeGraphicsDimensions();
}

void HashTable::initializeGraphicsDimensions()
{
    WINDOW_WIDTH = GetSystemMetrics(SM_CXSCREEN);
    WINDOW_HEIGHT = GetSystemMetrics(SM_CYSCREEN);
    CELL_WIDTH = (WINDOW_WIDTH / (TABLE_SIZE + 2));
    CELL_HEIGHT = CELL_WIDTH / 2;
    VERTICAL_SPACING = CELL_HEIGHT * 2;
    ARROW_HEIGHT = VERTICAL_SPACING / 2;
    START_X = (WINDOW_WIDTH - (TABLE_SIZE * CELL_WIDTH)) / 2;
    START_Y = (WINDOW_HEIGHT * 3) / 4;
    MAX_ELEMENTS_VERTICAL = (START_Y - 100) / VERTICAL_SPACING;
}

HashTable::~HashTable()
{
    for (int i = 0; i < TABLE_SIZE; i++)
    {
        HashNode *current = table[i];
        while (current != nullptr)
        {
            HashNode *next = current->next;
            delete current;
            current = next;
        }
    }
    delete[] table;
}

int HashTable::calculateXORHash(const std::string &value)
{
    int hash = 0;
    for (char c : value)
    {
        hash = (hash * 31 + (isLetterMode ? toupper(c) : c)) % TABLE_SIZE;
    }
    return hash;
}

int HashTable::hashFunction(std::string value)
{
    if (value.empty())
        return 0;
    return calculateXORHash(value);
}

int HashTable::linearProbing(int index, int i)
{
    return (index + i) % TABLE_SIZE;
}

int HashTable::quadraticProbing(int index, int i)
{
    return (index + i * i) % TABLE_SIZE;
}

int HashTable::doubleHashing(int index, int i, const std::string &value)
{
    return (index + i * hash2(value)) % TABLE_SIZE;
}

int HashTable::hash2(const std::string &value)
{
    int hash = 0;
    for (char c : value)
    {
        hash = (hash * 17 + (isLetterMode ? toupper(c) : c)) % TABLE_SIZE;
    }
    return hash == 0 ? 1 : hash; // Ensure hash2 is not zero
}

void HashTable::drawCurvedArrow(int x1, int y1, int x2, int y2)
{
    // Set a bright color that will be clearly visible
    setcolor(LIGHTGREEN);

    // Draw the main connecting line
    line(x1, y1, x2, y2);

    // Draw a simple arrowhead (two short lines)
    int arrowLength = 8; // Shorter arrow head
    int dx = x2 - x1;
    int dy = y2 - y1;
    double angle = atan2(dy, dx);

    // Calculate arrow head points
    int ax1 = x2 - arrowLength * cos(angle - 0.5);
    int ay1 = y2 - arrowLength * sin(angle - 0.5);
    int ax2 = x2 - arrowLength * cos(angle + 0.5);
    int ay2 = y2 - arrowLength * sin(angle + 0.5);

    // Draw arrow head lines
    line(x2, y2, ax1, ay1);
    line(x2, y2, ax2, ay2);
}

void HashTable::insert(std::string value)
{
    std::cout << "Insertando valor: " << value << std::endl; // Mensaje de depuración
    if (value.empty())
        return;

    if (isLetterMode)
    {
        if (!std::all_of(value.begin(), value.end(), ::isalpha))
        {
            std::cout << "Error: Solo se permiten letras en esta tabla.\n";
            system("pause");
            return;
        }
        std::transform(value.begin(), value.end(), value.begin(), ::toupper);
    }
    else
    {
        if (!std::all_of(value.begin(), value.end(), ::isdigit))
        {
            std::cout << "Error: Solo se permiten numeros en esta tabla.\n";
            system("pause");
            return;
        }
    }

    int index = hashFunction(value);
    int i = 0;
    int newIndex = index;

    while (table[newIndex] != nullptr)
    {
        i++;
        if (probingMethod == 1)
        {
            newIndex = linearProbing(index, i);
        }
        else if (probingMethod == 2)
        {
            newIndex = quadraticProbing(index, i);
        }
        else if (probingMethod == 3)
        {
            newIndex = doubleHashing(index, i, value);
        }
    }

    table[newIndex] = new HashNode(value);

    // Debug: verificar que el valor se insertó
    std::cout << "Insertado: " << value << " en indice: " << newIndex << std::endl;
}

bool HashTable::search(std::string value)
{
    if (value.empty())
        return false;

    int index = hashFunction(value);
    int i = 0;
    int newIndex = index;

    while (table[newIndex] != nullptr)
    {
        if (table[newIndex]->data == value)
            return true;

        i++;
        if (probingMethod == 1)
        {
            newIndex = linearProbing(index, i);
        }
        else if (probingMethod == 2)
        {
            newIndex = quadraticProbing(index, i);
        }
        else if (probingMethod == 3)
        {
            newIndex = doubleHashing(index, i, value);
        }
    }

    return false;
}

void HashTable::visualize()
{
    std::cout << "Visualizando tabla hash..." << std::endl; // Mensaje de depuración
    int gd = DETECT, gm;
    initwindow(WINDOW_WIDTH - 100, WINDOW_HEIGHT - 100, "Visualizacion de Tabla Hash");

    setbkcolor(WHITE); // Cambiado a WHITE
    cleardevice();

    // Título
    settextstyle(SANS_SERIF_FONT, HORIZ_DIR, 4); // Cambiado a SANS_SERIF_FONT y tamaño 4
    setcolor(MAGENTA); // Cambiado a MAGENTA
    std::string title = isLetterMode ? "Tabla Hash para Letras" : "Tabla Hash para Numeros";
    int titleWidth = textwidth((char *)title.c_str());
    int titleX = (getmaxx() - titleWidth) / 2;
    outtextxy(titleX, 30, (char *)title.c_str());

    std::cout << "Visualizando tabla hash..." << std::endl; // Debug

    // Dibujar tabla base
    for (int i = 0; i < TABLE_SIZE; i++)
    {
        int cellX = START_X + i * CELL_WIDTH;

        // Dibujar celda base (con relleno)
        setfillstyle(SOLID_FILL, LIGHTGRAY); // Cambiado a SOLID_FILL y LIGHTGRAY
        setcolor(RED); // Cambiado a RED
        bar(cellX, START_Y, cellX + CELL_WIDTH - 10, START_Y + CELL_HEIGHT); // Usar bar para relleno
        rectangle(cellX, START_Y, cellX + CELL_WIDTH - 10, START_Y + CELL_HEIGHT);

        // Dibujar índice
        settextstyle(SANS_SERIF_FONT, HORIZ_DIR, 2); // Cambiado a SANS_SERIF_FONT y tamaño 2
        setcolor(GREEN); // Cambiado a GREEN
        char index[5];
        sprintf(index, "[%d]", i);
        outtextxy(cellX + 10, START_Y + CELL_HEIGHT + 5, index);

        // Dibujar nodos
        HashNode *current = table[i];
        int nodeY = START_Y - VERTICAL_SPACING;

        if (current == nullptr)
        {
            std::cout << "Indice " << i << " esta vacio." << std::endl; // Debug
        }

        while (current != nullptr)
        {
            std::cout << "Dibujando: " << current->data << " en indice: " << i << std::endl; // Debug

            // Dibujar rectángulo sin relleno para el nodo
            setcolor(BLUE); // Cambiado a BLUE
            rectangle(cellX, nodeY, cellX + CELL_WIDTH - 10, nodeY + CELL_HEIGHT);

            // Dibujar el valor dentro del rectángulo
            settextstyle(SANS_SERIF_FONT, HORIZ_DIR, 2); // Cambiado a SANS_SERIF_FONT y tamaño 2
            setcolor(BLACK); // Cambiado a BLACK
            int textWidth = textwidth((char *)current->data.c_str());
            int textX = cellX + ((CELL_WIDTH - 10) - textWidth) / 2;
            outtextxy(textX, nodeY + CELL_HEIGHT / 4, (char *)current->data.c_str());

            // Dibujar línea conectora si hay un siguiente nodo
            if (current->next != nullptr)
            {
                setcolor(BLACK); // Cambiado a BLACK
                int lineX = cellX + (CELL_WIDTH - 10) / 2;
                line(lineX, nodeY + CELL_HEIGHT, lineX, nodeY + VERTICAL_SPACING);
            }

            current = current->next;
            nodeY -= VERTICAL_SPACING;
        }
    }

    // Mensaje de salida
    setcolor(RED); // Cambiado a RED
    settextstyle(SANS_SERIF_FONT, HORIZ_DIR, 2); // Cambiado a SANS_SERIF_FONT y tamaño 2
    const char *msg = "Presione cualquier tecla para volver al menu...";
    int msgWidth = textwidth((char *)msg);
    outtextxy((getmaxx() - msgWidth) / 2, getmaxy() - 30, (char *)msg);

    while (!kbhit())
    {
        delay(100);
    }
    getch();
    closegraph();
}
